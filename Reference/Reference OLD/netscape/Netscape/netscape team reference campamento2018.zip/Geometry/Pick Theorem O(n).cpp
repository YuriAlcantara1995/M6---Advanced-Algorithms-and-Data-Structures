/*A = I + B/2 - 1:
  A = Area of the polygon
  I = Number of integer coordinates points inside
  B = Number of integer coordinates points on the boundary
  Polygon's vertex must have integer coordinates */
ll points_on_segment(const line &s){
	point p = s[0] - s[1];
	return __gcd(abs(p.x), abs(p.y));
}
pair<ll, ll> pick_theorem(polygon &P){
	ll A = area2(P), B = 0, I = 0;
	for (int i = 0, n = P.size(); i < n; ++i)
		B += points_on_segment({P[i], P[NEXT(i)]});
	A = abs(A);
	I = (A - B) / 2 + 1;
	return {I, B};// < points inside, points in boundary>
}
